# -*- coding: utf-8 -*-
import json, time, os
from pathlib import Path
EVE = Path(os.environ.get("EVE_PATH","/var/log/suricata/eve.json"))
OUT = Path(os.environ.get("OUT_DIR","/var/forensic/out")); OUT.mkdir(parents=True, exist_ok=True)
def tail(fp):
    fp.seek(0, os.SEEK_END)
    while True:
        pos=fp.tell(); ln=fp.readline()
        if not ln: time.sleep(0.2); fp.seek(pos); continue
        yield ln
with EVE.open() as f, (OUT/"eve_features_ext.csv").open("a", encoding="utf-8") as w:
    w.write("ts,etype,src,sp,dst,dp,proto,tls_ver,sni,alpn,ja3,ja3s,quic_ver,quic_alpn,cid_len,retry,zrt\n")
    for ln in tail(f):
        try: ev=json.loads(ln)
        except: continue
        tls=ev.get("tls") or {}; qu=ev.get("quic") or {}
        row=[ev.get("timestamp"), ev.get("event_type"), ev.get("src_ip"), ev.get("src_port"), ev.get("dest_ip"), ev.get("dest_port"), ev.get("proto"),
             tls.get("version"), tls.get("sni"), tls.get("alpn"), tls.get("ja3"), tls.get("ja3s"),
             qu.get("version"), qu.get("alpn"), qu.get("cid_len"), qu.get("retry"), qu.get("zero_rtt")]
        w.write(",".join("" if x is None else str(x) for x in row)+"\n")
