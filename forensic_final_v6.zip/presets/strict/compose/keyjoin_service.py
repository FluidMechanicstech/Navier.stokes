# -*- coding: utf-8 -*-
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from typing import Optional
import os, time, json, subprocess, uuid
AUTH_ENV=os.environ.get("FOR_AUTH_TOKEN",""); TMP_DIR="/dev/shm/forensic_keylogs"; os.makedirs(TMP_DIR, exist_ok=True)
TTL_SEC=int(os.environ.get("KEYLOG_TTL","900"))
app=FastAPI(title="KeyJoin (Forensic)", version="1.0")
class IngestReq(BaseModel): keylog_text: str; label: Optional[str]=None
class IngestResp(BaseModel): keylog_id: str; expires_in: int
class DecryptReq(BaseModel): pcap_path: str; keylog_id: str; bpf: Optional[str]=None; limit: int=10000
class DecryptResp(BaseModel): decrypted_records: int; aead_tag_fail: int; http_records: int; quic_records: int; decrypt_ok_rate: float; notes: str
def _now(): return int(time.time())
def _gc():
    now=_now()
    for fn in os.listdir(TMP_DIR):
        fp=os.path.join(TMP_DIR,fn)
        try:
            if os.stat(fp).st_mtime+TTL_SEC<now: os.remove(fp)
        except: pass
@app.post("/keylog/ingest", response_model=IngestResp)
def ingest(req: IngestReq, x_forensic_auth: str = Header(default="")):
    if not AUTH_ENV or x_forensic_auth != AUTH_ENV: raise HTTPException(401,"invalid auth")
    _gc(); kid=uuid.uuid4().hex[:16]; path=os.path.join(TMP_DIR,f"{kid}.keylog")
    ALLOWED=("CLIENT_RANDOM","SERVER_RANDOM","CLIENT_HANDSHAKE_TRAFFIC_SECRET","SERVER_HANDSHAKE_TRAFFIC_SECRET","CLIENT_TRAFFIC_SECRET_0","SERVER_TRAFFIC_SECRET_0","EXPORTER_SECRET","EARLY_EXPORTER_SECRET")
    lines=[ln.strip()+"\n" for ln in req.keylog_text.splitlines() if ln.strip() and ln.split()[0] in ALLOWED]
    if not lines: raise HTTPException(400,"no valid keylog lines")
    open(path,"w").writelines(lines); os.utime(path,None)
    return IngestResp(keylog_id=kid, expires_in=TTL_SEC)
def _tshark_meta(pcap, keylog, bpf=None, limit=10000):
    cmd=["tshark","-r",pcap,"-T","json","-o",f"tls.keylog_file:{keylog}","-c",str(limit)]
    if bpf: cmd+=["-Y",bpf]
    try: out=subprocess.check_output(cmd,stderr=subprocess.DEVNULL,text=True)
    except Exception as e: return {"err":str(e)}
    try: data=json.loads(out)
    except: data=[]
    dec_ok=aead_fail=http=quic=0
    for pkt in data if isinstance(data,list) else []:
        fl=pkt.get("_source",{}).get("layers",{})
        if "http" in fl: http+=1
        if "quic" in fl: quic+=1
        if "tls" in fl:
            if "tls.app_data" in fl["tls"]: dec_ok+=1
            if "tls.alert_message" in fl["tls"]: aead_fail+=1
    total=max(1, dec_ok+aead_fail)
    return {"decrypted_records":dec_ok,"aead_tag_fail":aead_fail,"http_records":http,"quic_records":quic,"decrypt_ok_rate":dec_ok/total}
@app.post("/audit/decrypt", response_model=DecryptResp)
def audit(req: DecryptReq, x_forensic_auth: str = Header(default="")):
    if not AUTH_ENV or x_forensic_auth != AUTH_ENV: raise HTTPException(401,"invalid auth")
    keypath=os.path.join(TMP_DIR,f"{req.keylog_id}.keylog")
    if not os.path.exists(keypath): raise HTTPException(404,"keylog not found or expired")
    os.utime(keypath,None); meta=_tshark_meta(req.pcap_path,keypath,bpf=req.bpf,limit=req.limit)
    if "err" in meta: raise HTTPException(500,meta["err"])
    return DecryptResp(notes="meta-only; no plaintext persisted", **meta)
