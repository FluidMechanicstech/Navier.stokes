# -*- coding: utf-8 -*-
from fastapi import FastAPI, Header, Response
from pydantic import BaseModel, Field
from typing import List, Optional
import os, json, random
STATE_DIR = os.environ.get("STATE_DIR","/var/forensic/state"); os.makedirs(STATE_DIR, exist_ok=True)
def load_state():
    p=os.path.join(STATE_DIR,"ewq.json")
    if os.path.exists(p):
        try: return json.load(open(p,"r"))
        except: pass
    return {"rho":0.97,"alpha":0.01,"samples":[],"weights":[]}
def save_state(st): json.dump(st, open(os.path.join(STATE_DIR,"ewq.json"),"w"))
def ew_update(st, S_list):
    rho=st.get("rho",0.97); w_new=1.0-rho
    st["samples"]=[x*rho for x in st["samples"]]; st["weights"]=[x*rho for x in st["weights"]]
    for s in S_list: st["samples"].append(float(s)); st["weights"].append(w_new)
    save_state(st)
def ew_quantile(st):
    if not st["samples"]: return None
    s=sorted(zip(st["samples"],st["weights"]), key=lambda x:x[0]); tot=sum(w for _,w in s); acc=0.0; q=1.0-st.get("alpha",0.01)
    for v,w in s:
        acc += w/tot
        if acc>=q: return v
    return s[-1][0]
def bootstrap_tau(S, alpha=0.01, B=400):
    N=len(S); 
    if N==0: return None
    qs=[]; import random
    for _ in range(B):
        idx=[random.randrange(N) for __ in range(N)]; ss=[S[i] for i in idx]; ss.sort()
        k=max(0,int((1-alpha)*N)-1); qs.append(ss[k])
    qs.sort(); return qs[len(qs)//2]
app = FastAPI(title="Forensic-Decider", version="2.0")
STATE = load_state()
class DecisionReq(BaseModel):
    score_S: float; fp_tokens: List[str] = Field(default_factory=list); cost_weight: float = 1.0
    business_critical: bool = False; asn: Optional[int] = None; dst: Optional[str] = None
@app.post("/ingest")
def ingest(payload: List[float]):
    ew_update(STATE, payload)
    tau_ew = ew_quantile(STATE) or 3.0
    tau_bs = bootstrap_tau(STATE["samples"], alpha=STATE.get("alpha",0.01)) or tau_ew
    tau = 0.5*tau_ew + 0.5*tau_bs
    return {"tau_ew": tau_ew, "tau_bs": tau_bs, "tau": tau, "n": len(STATE["samples"])}
def compute_decision(S, biz, asn, cost):
    tau_ew = ew_quantile(STATE) or 3.0
    tau_bs = bootstrap_tau(STATE["samples"], alpha=STATE.get("alpha",0.01)) or tau_ew
    tau = 0.5*tau_ew + 0.5*tau_bs
    if biz: tau *= 1.2
    if asn in {15169,16509}: tau *= 1.1
    if S >= tau*1.1: return "terminate", tau
    if S >= tau: return "audit", tau
    return "allow", tau
@app.post("/decision")
def decision(req: DecisionReq):
    dec, tau = compute_decision(req.score_S, req.business_critical, req.asn, req.cost_weight)
    return {"decision": dec, "threshold": tau}
@app.get("/authz")
def authz(response: Response,
          x_score_s: float = Header(..., alias="X-Score-S"),
          x_ja_tokens: str = Header("", alias="X-JA-Tokens"),
          x_asn: int = Header(0, alias="X-ASN"),
          x_biz_critical: int = Header(0, alias="X-Biz-Critical")):
    dec, tau = compute_decision(float(x_score_s), bool(x_biz_critical), int(x_asn), 1.0)
    response.headers["x-decision"] = dec; response.headers["x-threshold"] = str(tau)
    response.status_code = 403 if dec=="terminate" else 200
    return {"decision":dec,"tau":tau}
