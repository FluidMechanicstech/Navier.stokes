
#!/usr/bin/env bash
set -euo pipefail
ISO_URL="${DESKTOP_ISO_URL:-https://releases.ubuntu.com/24.04/ubuntu-24.04.1-desktop-amd64.iso}"
ISO_NAME="${ISO_NAME:-$(basename "$ISO_URL")}"
VOLUME_LABEL="${VOLUME_LABEL:-Ubuntu-Forensic-Desktop-v6-strict}"
WORKDIR="${WORKDIR:-$PWD/work}"; OUTDIR="${OUTDIR:-$PWD/out}"; OVERLAY_DIR="${OVERLAY_DIR:-$PWD/overlay}"
mkdir -p "$WORKDIR" "$OUTDIR"; cd "$WORKDIR"
[ -f "$ISO_NAME" ] || wget -O "$ISO_NAME" "$ISO_URL"
sudo rm -rf mnt iso-root edit; mkdir -p mnt iso-root
sudo mount -o loop "$ISO_NAME" mnt; rsync -a mnt/ iso-root/; sudo umount mnt
SQ=iso-root/casper/filesystem.squashfs; [ -f "$SQ" ] || { echo "no casper squashfs"; exit 1; }
sudo unsquashfs -d edit "$SQ"
sudo mount --bind /dev edit/dev; sudo mount -t proc /proc edit/proc; sudo mount -t sysfs /sys edit/sys; sudo mount -t tmpfs tmpfs edit/run || true
sudo cp /etc/resolv.conf edit/etc/; [ -d "$OVERLAY_DIR" ] && sudo rsync -a "$OVERLAY_DIR"/ edit/
sudo chroot edit bash -c "export DEBIAN_FRONTEND=noninteractive; apt-get update || true"
sudo chroot edit bash -c "export DEBIAN_FRONTEND=noninteractive; apt-get install -y --no-install-recommends docker.io docker-compose-plugin suricata zeek zkg tshark jq curl ca-certificates"
sudo chroot edit bash -c "mkdir -p /etc/systemd/system/multi-user.target.wants && ln -sf /etc/systemd/system/forensic-compose.service /etc/systemd/system/multi-user.target.wants/forensic-compose.service"
sudo rm -f edit/etc/resolv.conf || true; sudo umount -lf edit/run || true; sudo umount -lf edit/sys; sudo umount -lf edit/proc; sudo umount -lf edit/dev
sudo rm -f "$SQ"; sudo mksquashfs edit "$SQ" -comp xz -b 1M -Xbcj x86
printf $(sudo du -sx --block-size=1 edit | cut -f1) > iso-root/casper/filesystem.size
cd iso-root; sudo rm -f md5sum.txt; find . -type f -print0 | grep -vzZ "./md5sum.txt" | xargs -0 md5sum | sudo tee md5sum.txt >/dev/null; cd ..
xorriso -as mkisofs -r -V "$VOLUME_LABEL" -o "$OUTDIR/ubuntu-forensic-desktop-v6-strict.iso" \
  -J -l -iso-level 3 -cache-inodes -eltorito-alt-boot -e boot/grub/efi.img -no-emul-boot -isohybrid-gpt-basdat iso-root
echo "[+] ISO: $OUTDIR/ubuntu-forensic-desktop-v6-strict.iso"
