
# Forensic Inline ISO **FINAL v6** — 하드코딩 프리셋(Strict/Corp/Research)
- Envoy 게이트 + EW-분위/부트스트랩 τ decider + KeyJoin(SSLKEYLOGFILE 메타 복호) + Suricata watcher + Compose 자동기동.
- 프리셋 차등: Envoy 포트/업스트림, JA4 ALPN/SNI bins, 0-RTT 플래그, 티켓 길이 bins, Zeek 샘플링률.
