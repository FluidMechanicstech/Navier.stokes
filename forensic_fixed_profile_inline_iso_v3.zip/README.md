
# Fixed-Profile Inline ISO v3 — **탐지→(합법)키 확보→메타 복호 검사→재암호화**
- 기존 번들(탐지/게이트/프로파일/캘리브레이션/JA4Q/QUIC/Envoy·Nginx 결선)을 유지.
- **추가**: 포렌식 **KeyLog 인게스트 + 세션 조인 + 메타 복호 점검** 파이프라인.
- 목적: **승인된 환경**에서 세션키를 **KeyLog**(또는 구형 RSA KX의 서버 키)로 입력받아,
  패킷을 **복호 가능한지·태그 검증이 통과하는지** 등 *메타*를 산출. 평문/키 **저장 금지**.

## 새 구성 개요
- `compose/keyjoin_service.py`: FastAPI
  - `POST /keylog/ingest` — `X-Forensic-Auth` 토큰 필요. KeyLog 라인을 **tmpfs(/dev/shm)**에 저장.
  - `POST /audit/decrypt` — 의심 세션(PCAP, BPF/시간창) + KeyLog ID로 **tshark**를 호출해
    **복호 가능 여부·AEAD 태그 검증 통과률** 등 **메타 통계**만 생성.
  - (옵션) RSA KX(구형 TLS)용 PEM 경로 지정 지원(버전 호환 주석 참고).
- `tools/decrypt_meta.py`: CLI 래퍼. `tls.keylog_file` 옵션만 사용(평문 덤프 금지).
- `compose/docker-compose.yml`: 서비스 `keyjoin` 추가. `FOR_AUTH_TOKEN` 필요.
- `overlay/etc/systemd/system/forensic-compose.service`: 부팅 시 `docker compose up -d` 자동 기동.

> 법/정책 준수 전제. **평문/세션키는 디스크 저장 금지**, 메타(카운트/검증율/요약)만 기록.
