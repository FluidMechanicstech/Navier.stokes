#!/usr/bin/env python3
# CLI: decrypt_meta.py <pcap> <keylog_id> [--bpf 'tls || quic'] [--limit 5000]
import os, sys, requests, argparse
DECIDER = os.environ.get("KEYJOIN","http://localhost:8788")
AUTH = os.environ.get("FOR_AUTH_TOKEN","")
ap = argparse.ArgumentParser()
ap.add_argument("pcap"); ap.add_argument("keylog_id")
ap.add_argument("--bpf", default=None)
ap.add_argument("--limit", type=int, default=5000)
ns = ap.parse_args()
r = requests.post(f"{DECIDER}/audit/decrypt",
                  headers={"X-Forensic-Auth": AUTH},
                  json={"pcap_path": ns.pcap, "keylog_id": ns.keylog_id, "bpf": ns.bpf, "limit": ns.limit})
print(r.status_code, r.json())
