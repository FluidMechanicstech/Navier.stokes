# -*- coding: utf-8 -*-
from fastapi import FastAPI, Header, Response
app = FastAPI(title="Forensic-Decider v3-stub")
TAU = 3.0
@app.get("/authz")
def authz(response: Response, x_score_s: float = Header(..., alias="X-Score-S")):
    dec = "allow"
    if x_score_s >= TAU*1.1: dec="terminate"
    elif x_score_s >= TAU: dec="audit"
    response.headers["x-decision"]=dec
    response.headers["x-threshold"]=str(TAU)
    response.status_code=200 if dec!="terminate" else 403
    return {"decision":dec,"tau":TAU}
