# -*- coding: utf-8 -*-
"""
KeyJoin Service (forensic, authorized only)
- Accepts TLS Key Log lines (SSLKEYLOGFILE style) with an auth token.
- Stores to tmpfs (/dev/shm/forensic_keylogs) with short TTL.
- Provides /audit/decrypt endpoint to run tshark with -o tls.keylog_file and produce *metadata* only:
  - decrypted_records, decrypt_ok_rate, aead_tag_fail_count, http_seen_count, quic_seen_count
- No plaintext or key material persisted to disk. Key files live only in tmpfs and are GC'ed by TTL.
- Optional: RSA key (legacy TLS RSA key exchange only) path can be passed (see notes), but modern TLS 1.3/1.2 ECDHE uses keylog.
"""
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List
import os, time, json, subprocess, tempfile, uuid, shutil

AUTH_ENV = os.environ.get("FOR_AUTH_TOKEN","")
TMP_DIR = "/dev/shm/forensic_keylogs"
os.makedirs(TMP_DIR, exist_ok=True)

TTL_SEC = int(os.environ.get("KEYLOG_TTL","900"))  # 15 min default

app = FastAPI(title="KeyJoin (Forensic)", version="1.0")

class IngestReq(BaseModel):
    keylog_text: str = Field(..., description="SSLKEYLOGFILE formatted lines")
    label: Optional[str] = None  # optional hint

class IngestResp(BaseModel):
    keylog_id: str
    expires_in: int

class DecryptReq(BaseModel):
    pcap_path: str
    keylog_id: str
    bpf: Optional[str] = None
    time_from: Optional[float] = None  # epoch seconds
    time_to: Optional[float] = None
    rsa_pem: Optional[str] = None  # LEGACY ONLY (TLS RSA KX), path inside host/container
    mode: str = Field("auto", description="auto|tls|quic")
    limit: int = 10000

class DecryptResp(BaseModel):
    decrypted_records: int
    aead_tag_fail: int
    http_records: int
    quic_records: int
    decrypt_ok_rate: float
    notes: str

def _now(): return int(time.time())

def _gc():
    now = _now()
    for fn in os.listdir(TMP_DIR):
        fp = os.path.join(TMP_DIR, fn)
        try:
            if os.stat(fp).st_mtime + TTL_SEC < now:
                os.remove(fp)
        except: pass

@app.post("/keylog/ingest", response_model=IngestResp)
def ingest(req: IngestReq, x_forensic_auth: str = Header(default="")):
    if not AUTH_ENV or x_forensic_auth != AUTH_ENV:
        raise HTTPException(401, "invalid auth")
    _gc()
    kid = uuid.uuid4().hex[:16]
    path = os.path.join(TMP_DIR, f"{kid}.keylog")
    # Basic sanity: keep only recognized prefixes to reduce risk
    ALLOWED_PREFIX = (
        "CLIENT_RANDOM","SERVER_RANDOM","CLIENT_HANDSHAKE_TRAFFIC_SECRET",
        "SERVER_HANDSHAKE_TRAFFIC_SECRET","CLIENT_TRAFFIC_SECRET_0",
        "SERVER_TRAFFIC_SECRET_0","EXPORTER_SECRET","EARLY_EXPORTER_SECRET"
    )
    lines = []
    for ln in req.keylog_text.splitlines():
        ln = ln.strip()
        if not ln: continue
        if any(ln.startswith(p) for p in ALLOWED_PREFIX):
            lines.append(ln+"\n")
    if not lines:
        raise HTTPException(400, "no valid keylog lines")
    with open(path,"w") as w: w.writelines(lines)
    os.utime(path, (time.time(), time.time()))
    return IngestResp(keylog_id=kid, expires_in=TTL_SEC)

def _tshark_meta(pcap, keylog, bpf=None, limit=10000, rsa_pem=None, mode="auto"):
    """
    Calls tshark in metadata-only way. Requires host to have tshark.
    Returns counts by scanning JSON output of selected fields.
    """
    cmd = ["tshark","-r",pcap,"-T","json"]
    # Filter selection
    if bpf: cmd += ["-Y", bpf]
    # Key material
    cmd += ["-o", f"tls.keylog_file:{keylog}"]
    # (LEGACY) RSA key exchange support is version-dependent; not enabled by default.
    # If needed and supported by your tshark version, you may add one of the following prefs:
    # -o "tls.key_file: ,<path_to_pem>"
    if rsa_pem:
        cmd += ["-o", f"tls.key_file: ,{rsa_pem}"]
    # Fields reasonably safe for meta (no payload/values)
    F = [
        "-e","_ws.col.Protocol",
        "-e","tcp.stream",
        "-e","quic",
        "-e","http.request.method",
        "-e","http.host",
        "-e","tls.app_data",
        "-e","tls.record.version",
        "-e","tls.alert_message"
    ]
    for f in F: cmd += [f]
    # Limit
    cmd += ["-c", str(limit)]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True)
    except Exception as e:
        return {"err": str(e)}
    # Parse minimal JSON if available
    try:
        data = json.loads(out)
    except Exception:
        data = []
    dec_ok=0; aead_fail=0; http=0; quic=0
    for pkt in data if isinstance(data, list) else []:
        # Heuristic: presence of http fields indicates decryption of HTTP over TLS
        fl = pkt.get("_source",{}).get("layers",{})
        if "http" in fl: http += 1
        if "quic" in fl: quic += 1
        # AEAD fail detection is not standardized in JSON; we rely on absence of alerts and presence of application data
        if "tls" in fl:
            if "tls.app_data" in fl.get("tls",{}): dec_ok += 1
            if "tls.alert_message" in fl.get("tls",{}): aead_fail += 1
    total = max(1, dec_ok + aead_fail)
    return {"decrypted_records": dec_ok, "aead_tag_fail": aead_fail, "http_records": http, "quic_records": quic, "decrypt_ok_rate": dec_ok/total}

@app.post("/audit/decrypt", response_model=DecryptResp)
def audit(req: DecryptReq, x_forensic_auth: str = Header(default="")):
    if not AUTH_ENV or x_forensic_auth != AUTH_ENV:
        raise HTTPException(401, "invalid auth")
    keypath = os.path.join(TMP_DIR, f"{req.keylog_id}.keylog")
    if not os.path.exists(keypath):
        raise HTTPException(404, "keylog not found or expired")
    # Touch TTL
    os.utime(keypath, None)
    meta = _tshark_meta(req.pcap_path, keypath, bpf=req.bpf, limit=req.limit, rsa_pem=req.rsa_pem, mode=req.mode)
    if "err" in meta:
        raise HTTPException(500, meta["err"])
    return DecryptResp(notes="meta-only; no plaintext persisted", **meta)
