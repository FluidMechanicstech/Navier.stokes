# -*- coding: utf-8 -*-
# Simple Suricata eve watcher (extended fields placeholder)
import json, time, os
from pathlib import Path
EVE = Path(os.environ.get("EVE_PATH","/var/log/suricata/eve.json"))
OUT = Path(os.environ.get("OUT_DIR","/var/forensic/out")); OUT.mkdir(parents=True, exist_ok=True)
FIELDS=["ts","etype","src","sp","dst","dp","proto","tls_ver","sni","alpn","ja3","ja3s","quic_ver","quic_alpn"]
def tail(fp):
    fp.seek(0, os.SEEK_END)
    while True:
        pos=fp.tell(); line=fp.readline()
        if not line: time.sleep(0.2); fp.seek(pos); continue
        yield line
with EVE.open() as f, (OUT/"eve_features_min.csv").open("a", encoding="utf-8") as w:
    w.write(",".join(FIELDS)+"\n")
    for ln in tail(f):
        try: ev=json.loads(ln)
        except: continue
        tls=ev.get("tls") or {}; qu=ev.get("quic") or {}
        row=[ev.get("timestamp"), ev.get("event_type"), ev.get("src_ip"), ev.get("src_port"), ev.get("dest_ip"), ev.get("dest_port"), ev.get("proto"),
             tls.get("version"), tls.get("sni"), tls.get("alpn"), tls.get("ja3"), tls.get("ja3s"),
             qu.get("version"), qu.get("alpn")]
        w.write(",".join("" if x is None else str(x) for x in row)+"\n")
